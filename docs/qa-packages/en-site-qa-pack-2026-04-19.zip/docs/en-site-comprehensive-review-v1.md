# AshleyKitchen EN Site Comprehensive Review (v1)
Date: 2026-04-18  
Reviewer: Codex (GPT-5)  
Scope: `index.html`, `catalog.html`, `catalog-stone.html`, `plye.html`, `nalexible-stone.html`, `nalexible-fiberboard.html`, `applications.html`, `projects.html`, `about.html`, `contact.html` (+ SEO/control files)

## Method
- Static code/content review (IA, flow, copy, UI consistency, CTA logic, baseline accessibility semantics).
- Link-path integrity check across primary EN pages (no missing local targets found).
- Responsive rule review from CSS breakpoints (desktop/tablet/mobile grid logic).
- Note: no live-browser automated interaction run in this pass.

## Launch Verdict
- **Verdict: Conditional GO**
- **Blocking before public launch (recommended):**
1. Remove/disable public A/B debug entry on homepage.
2. Fix non-functional language toggle behavior on EN pages that still show the switcher.
3. Expand sitemap coverage to include all production pages.

---

## Findings (by severity)

### Critical
- None found in this pass.

### High
1. **Public-facing A/B debug/report exposure on homepage**
   - File: `/Users/adamchen/Desktop/web_dev/index.html:1086`
   - Evidence: visible badge links to `ab-report.html`.
   - Impact: leaks internal experiment scaffolding to end users, reduces trust/polish, creates confusing UX branch.
   - Fix: hide in production with build flag or remove entirely; keep report page non-linked.

2. **Language switcher appears but is non-functional on some EN pages**
   - Files:
     - `/Users/adamchen/Desktop/web_dev/about.html:348`
     - `/Users/adamchen/Desktop/web_dev/about.html:350`
     - `/Users/adamchen/Desktop/web_dev/plye.html:442`
     - `/Users/adamchen/Desktop/web_dev/plye.html:444`
   - Evidence: buttons rendered without `onclick`/handler binding and no language application routine in those pages.
   - Impact: users click language control and nothing happens; harms credibility and accessibility expectations.
   - Fix: either implement full bilingual toggle consistently, or hide the switcher on EN-only pages.

3. **Sitemap is materially incomplete for current site IA**
   - File: `/Users/adamchen/Desktop/web_dev/sitemap.xml:1-32`
   - Evidence: includes only 4 URLs (`/`, `plye.html`, `nalexible-stone.html`, `nalexible-fiberboard.html`) while key live pages (`catalog`, `catalog-stone`, `applications`, `projects`, `about`, `contact`) are missing.
   - Impact: SEO crawl coverage and discoverability loss; weak alignment with current site structure.
   - Fix: regenerate sitemap with all canonical production routes and alternate hreflang entries where applicable.

### Medium
4. **Duplicate DOM `id` value in Applications page**
   - File:
     - `/Users/adamchen/Desktop/web_dev/applications.html:296`
     - `/Users/adamchen/Desktop/web_dev/applications.html:315`
   - Evidence: `id="residential"` appears twice.
   - Impact: anchor targeting ambiguity, JS selector instability, accessibility parser confusion.
   - Fix: make IDs unique (`residential-row-1`, `residential-row-2`) and update any selectors.

5. **Internal placeholder/change-log style copy visible to customers**
   - File: `/Users/adamchen/Desktop/web_dev/catalog-stone.html:1235`
   - Evidence: “Next upgrades can replace placeholder visuals...”
   - Impact: reads like internal production note, not customer-facing content; weakens premium tone.
   - Fix: rewrite as customer value statement or remove.

6. **Primary CTA strategy is inconsistent across top navs**
   - Files (examples):
     - `/Users/adamchen/Desktop/web_dev/index.html:1123` (`Contact`)
     - `/Users/adamchen/Desktop/web_dev/catalog.html:558` (`Request a Sample`)
     - `/Users/adamchen/Desktop/web_dev/catalog-stone.html:1029` (`Request a Sample`)
   - Impact: funnel priority shifts by page context; may reduce conversion clarity.
   - Fix: define one global top-nav primary CTA rule (recommended: sample-first with intent-prefill), keep secondary contact paths in-page/footer.

7. **Experimental/legacy pages likely deployable and indexable**
   - Files present at root include:
     - `ab-report.html`
     - `plye-b.html`
     - `plye-c.html`
     - `stone-catalog.html`
     - `_lumislate-mockup.html`, `_card_test.html`, `_duplicates.html`, `_poster_candidates.html`
   - Impact: if publicly served, can create duplicate/confusing experiences and dilute SEO signals.
   - Fix: remove from production artifact, or add `noindex` and ensure no nav/internal links from production pages.

### Low
8. **Duplicate heading line in About process card**
   - File: `/Users/adamchen/Desktop/web_dev/about.html:560`
   - Evidence: repeated `h3` (“Support samples and proof”) appears twice in same card.
   - Impact: visual/editorial quality issue; minor accessibility noise.
   - Fix: remove duplicate line.

9. **Potentially over-committed delivery promise in metadata**
   - File: `/Users/adamchen/Desktop/web_dev/contact.html:29`
   - Evidence: Twitter description claims “Free samples delivered within 5 business days.”
   - Impact: if operations cannot always meet this, creates compliance/trust risk.
   - Fix: soften to SLA-safe wording (e.g., “respond as soon as possible” / “typical lead time”).

---

## Cross-Platform and UI/Flow Summary
- **Grid logic:** `catalog-stone` series library now uses stable 5/3/2 pattern grid for Series 3–8; good for desktop/tablet/mobile readability.
- **Flow:** homepage → catalog → catalog-stone → contact intents is coherent and mostly well prefilled.
- **UI consistency:** generally strong visual direction; remaining variance is mostly CTA language and language-switch behavior.
- **Link integrity:** no missing local file targets found in primary EN pages.

## Recommended Next Pass
1. Fix 3 High items first (A/B badge, lang switch behavior, sitemap).
2. Clean Medium copy/ID issues in one commit batch.
3. Run a quick manual interaction QA after fixes:
   - Desktop 1440
   - Tablet 1024
   - Mobile 390/430
   - EN/ZH switch path
   - Top 10 CTA routes to `contact.html` prefill behavior.
