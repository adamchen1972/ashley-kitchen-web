# EN Site Independent QA Review (v2)
Date: 2026-04-18
Reviewer: Claude (Sonnet/Opus, independent pass)
Scope: `index.html`, `catalog.html`, `catalog-stone.html`, `plye.html`, `nalexible-stone.html`, `nalexible-fiberboard.html`, `applications.html`, `projects.html`, `about.html`, `contact.html`, plus `sitemap.xml`, `robots.txt`, and production-surface hygiene.
Comparison targets:
- `docs/en-site-comprehensive-review-v1.md` (Codex / GPT-5)
- `docs/en-site-remediation-checklist-v1.md` (Codex / GPT-5)

Pass type: **Audit only, no edits.**

---

## Executive Summary

- **Verdict: NO-GO for public launch** (stricter than Codex's Conditional GO).
- Primary reason for the stricter verdict: `contact.html` has no server-side submission path. The form is wired to a `mailto:` handoff that fails silently on desktops without a configured default mail client and is non-functional for many mobile browsers. For a lead-capture site whose main conversion objective is the contact/sample path, this is a revenue-blocking defect, not a polish item.
- Secondary blockers: missing `<main>` landmark on `catalog.html` and `catalog-stone.html` (a11y + SEO structural regression on the two highest-intent pages), plus all three High items Codex already flagged (A/B badge exposure, non-functional lang toggle, incomplete sitemap).
- Polish-level issues: nav CTA inconsistency, legacy/test pages present at repo root, Products ▾ placeholder href, `twitter:description` over-committed SLA, missing `<link rel="canonical">` on two pages, and brand-led `<title>` strings on two product pages.
- I confirm 8 of 9 Codex findings. I **reject Codex L-8** (alleged duplicate `<h3>` "Support samples and proof" in `about.html`) as factually incorrect after grep verification.

---

## Method

- Static source review of the 10 EN pages plus `script.js` (171 KB), `sitemap.xml`, `robots.txt`, and the legacy file surface at repo root.
- Grep/Glob verification for each Codex-claimed finding (line-by-line confirmation or rejection).
- Cross-page consistency checks for: nav CTA text and query intent, `<main>` landmark presence, `<link rel="canonical">` presence, `<title>` structure, language-bar handler binding, and class naming.
- Disk verification of asset references (image paths used by `SERIES_PATTERN_LIBRARY` in `catalog-stone.html` were all verified present on disk earlier in this session).
- No live-browser automated interaction was run in this pass.

---

## Independent Findings (severity-ranked)

### Critical

**C-1. Contact form has no server-side submission path; relies on `mailto:` redirect**
- File: `/Users/adamchen/Desktop/web_dev/contact.html`
- Evidence: `<form action="#" method="post" id="contact-form">` at line 428; submit handler at lines 1066–1139 builds a `mailto:adam@ashleykitchen.co` URL at line 1122 and assigns it to `window.location.href`. No `fetch`, no XHR, no third-party form service.
- Impact: on any device without a configured default mail client (most Chrome/Safari desktops in 2026, many mobile browsers with webmail-only setups), the submit either no-ops, opens a blank composer, or routes to the wrong account. Lead capture is the site's primary conversion goal; this is a revenue-blocking defect.
- Why it is Critical (and not High): Codex scoped the pass to IA/copy/sitemap and did not exercise submission. For a brochure site with a single conversion action, a silent-failure submit path is a launch blocker.

### High

**H-1. Public-facing A/B debug entry on homepage** (confirms Codex H-1)
- File: `/Users/adamchen/Desktop/web_dev/index.html:1086`
- Evidence: `<a class="ab-variant-badge" id="ab-variant-badge" href="ab-report.html" title="Open CTA report dashboard">Homepage A</a>`
- Impact: exposes internal experimentation scaffolding; `ab-report.html` is reachable from the public homepage.
- Fix: remove the badge, or gate it behind a build flag; keep `ab-report.html` out of production artifact.

**H-2. Missing `<main>` landmark on high-intent catalog pages**
- Files:
  - `/Users/adamchen/Desktop/web_dev/catalog.html` (no `<main>` occurrence)
  - `/Users/adamchen/Desktop/web_dev/catalog-stone.html` (no `<main>` occurrence)
- Impact: screen readers lose the primary content region on the two pages that carry the product offer; SEO loses the conventional main-content anchor; CSS rule `main { padding-top: 138px }` cannot apply, leaving header-overlap risk on any sub-hero content. This is a structural regression that Codex did not flag.
- Fix: wrap the core content in `<main>` with appropriate `id`/`role` where needed.

**H-3. Language switcher renders but is non-functional on EN pages** (confirms Codex H-2)
- Files:
  - `/Users/adamchen/Desktop/web_dev/about.html:348,350`
  - `/Users/adamchen/Desktop/web_dev/plye.html:442,444`
- Evidence: `.lang-btn` buttons present in DOM but missing `onclick="setLang('en')"` / `onclick="setLang('zh')"` bindings. `setLang` is defined in `script.js:1484` and does update `document.documentElement.lang` at line 1497, so the switch would work if wired.
- Impact: user clicks language control and nothing happens; credibility loss, a11y expectation violation.
- Fix: either wire the handlers consistently, or hide the switcher on EN-only pages.

**H-4. Sitemap is materially incomplete** (confirms Codex H-3)
- File: `/Users/adamchen/Desktop/web_dev/sitemap.xml` (1,574 bytes, 4 URLs)
- Evidence: only `/`, `plye.html`, `nalexible-stone.html`, `nalexible-fiberboard.html` are listed. Missing: `catalog.html`, `catalog-stone.html`, `applications.html`, `projects.html`, `about.html`, `contact.html`.
- Impact: ~60% of production routes excluded from crawl signal.
- Fix: regenerate with full canonical coverage and `hreflang` alternates where EN/ZH apply.

### Medium

**M-1. Primary CTA strategy inconsistent across top navs** (confirms Codex M-6)
- Files (examples):
  - `/Users/adamchen/Desktop/web_dev/index.html:1123` → `Contact` (intent=`project_support`)
  - `/Users/adamchen/Desktop/web_dev/catalog.html:558` → `Request a Sample` (intent=`sample`)
  - `/Users/adamchen/Desktop/web_dev/catalog-stone.html:1029` → `Request a Sample` (intent=`sample`)
- Impact: funnel priority shifts by page; reduces conversion clarity.
- Fix: pick one global nav-CTA rule (recommended: sample-first with intent prefill), push "Contact" to secondary/footer slot.

**M-2. Duplicate DOM `id="residential"` on Applications page** (confirms Codex M-4)
- File: `/Users/adamchen/Desktop/web_dev/applications.html:296, 315`
- Impact: anchor-link ambiguity, JS selector instability, a11y parser confusion.
- Fix: rename to `residential-headers` / `residential-row-1` and update any selectors.

**M-3. Experimental/legacy pages present at production root** (confirms Codex M-7)
- Files at root: `ab-report.html`, `plye-b.html`, `plye-c.html`, `stone-catalog.html`, `_lumislate-mockup.html`, `_card_test.html`, `_duplicates.html`, `_poster_candidates.html`, `_fb_master_browser.html`.
- Impact: if publishable, these produce duplicate/confusing surfaces and dilute SEO signal.
- Fix: exclude from production artifact via deploy allowlist; if any must remain, apply `noindex` and ensure no production page links to them.

**M-4. Internal placeholder/change-log copy visible on customer surface** (confirms Codex M-5)
- File: `/Users/adamchen/Desktop/web_dev/catalog-stone.html:1235`
- Evidence: "Next upgrades can replace placeholder visuals..."
- Impact: reads as internal production note; weakens premium tone.
- Fix: rewrite as a customer value statement or remove.

**M-5. `Products ▾` nav trigger uses `href="#"` placeholder**
- File: `/Users/adamchen/Desktop/web_dev/catalog.html:545`
- Evidence: `<a href="#" id="cat-products-nav" class="nav-dropdown-trigger">Products ▾</a>`
- Impact: keyboard users and no-JS crawlers land on the top of the page when they activate the trigger; dropdown behavior becomes the only real path. Also a discoverability/SEO issue.
- Fix: point `href` to the canonical products landing (e.g. `/catalog.html#products` or `/catalog-stone.html`), preserve dropdown as an enhancement.

**M-6. Merchant links are placeholder `href="#"` anchors**
- File: `/Users/adamchen/Desktop/web_dev/contact.html:763–765`
- Evidence: three anchors (Amazon / MOMO / PChome) point to `#`.
- Impact: users tapping through to buy online experience a dead link on a customer-facing page; trust signal weakened.
- Fix: either complete the links, or hide the merchant block until destinations exist.

**M-7. `robots.txt` does not block legacy/test surface**
- File: `/Users/adamchen/Desktop/web_dev/robots.txt` (78 bytes)
- Evidence: only `Allow: /` plus the sitemap URL. No `Disallow:` rules against `ab-report.html`, `_*`, `plye-b.html`, `plye-c.html`, `stone-catalog.html`.
- Impact: even if those pages are not linked, crawlers that probe by convention can index them.
- Fix: add explicit `Disallow:` entries, or (preferred) remove the files from the deploy artifact.

### Low

**L-1. Over-committed delivery promise in `twitter:description`** (confirms Codex L-9)
- File: `/Users/adamchen/Desktop/web_dev/contact.html:29`
- Evidence: "Free samples delivered within 5 business days."
- Impact: SLA/compliance risk if ops cannot hold the promise.
- Fix: soften to "typical lead time" or remove the specific day count.

**L-2. Missing `<link rel="canonical">` on two pages**
- Files:
  - `/Users/adamchen/Desktop/web_dev/catalog.html`
  - `/Users/adamchen/Desktop/web_dev/applications.html`
- Impact: inconsistent canonicalization across the site; small SEO signal loss.
- Fix: add canonical tags matching the rest of the page set.

**L-3. Supplier brand dominates `<title>` on two product pages**
- Files:
  - `/Users/adamchen/Desktop/web_dev/nalexible-stone.html:13` → `<title>Nalexible Stone | ...</title>`
  - `/Users/adamchen/Desktop/web_dev/nalexible-fiberboard.html:13` → `<title>Nalexible Fiberboard | ...</title>`
- Impact: supplier brand leads the SERP snippet; house brand (AshleyKitchen) gets demoted. Not a bug, but a positioning choice that should be made deliberately.
- Fix: front-load the category ("Flexible Stone Veneer — Nalexible | AshleyKitchen") or keep as is, once deliberate.

**L-4. A/B variant ships two `<h1>` elements in the DOM**
- File: `/Users/adamchen/Desktop/web_dev/index.html:1162–1163`
- Evidence: both `.ab-a-only` and `.ab-b-only` `<h1>` elements render; the inactive one is hidden via CSS class toggled by the A/B init at line 1534.
- Impact: when CSS is still loading or disabled, both H1s are briefly visible; SEO crawlers see two H1s on a page where there should be one.
- Fix: render a single H1 and swap text content via JS once the variant is determined, or use `server`-side variant selection.

**L-5. Focus-visible / keyboard-nav styling not uniformly applied**
- Multiple files.
- Impact: a11y baseline — users tabbing through the site get inconsistent focus indicators, especially on card and CTA patterns.
- Fix: define a global `:focus-visible` rule and audit hero CTAs + card anchors.

**L-6. Class naming conventions mixed across pages**
- Example symptoms: `kebab-case-grid`, `camelCaseList`, inline style overrides for what is otherwise utility-class territory.
- Impact: maintenance cost; new contributors pay a tax.
- Fix: schedule a normalization pass after launch; not blocking.

---

## Rejected Codex Findings

**REJECT Codex L-8 — "Duplicate heading line in About process card"**
- Codex claim: `about.html:560` contains `<h3>Support samples and proof</h3>` twice inside the same card.
- Verification: grep across `about.html` finds the string "Support samples and proof" only once (line 560). The four process-card headings are distinct:
  - Line 550: `Understand the buyer or project` (Step 01)
  - Line 555: `Match the right family` (Step 02)
  - Line 560: `Support samples and proof` (Step 03)
  - Line 565: `Move into specification or purchase` (Step 04)
- Conclusion: the finding is factually wrong and should be removed from the remediation checklist. No edit required for this line item.

---

## Match / Diff vs Codex

Codex finding → my position.

- Codex Critical: (none) → I **add one Critical (C-1, contact-form mailto-only)**; Codex under-scoped form behavior.
- Codex H-1 (AB badge) → **Confirm** as H-1.
- Codex H-2 (lang switch non-functional) → **Confirm** as H-3.
- Codex H-3 (sitemap incomplete) → **Confirm** as H-4.
- Codex M-4 (duplicate `id="residential"`) → **Confirm** as M-2.
- Codex M-5 (internal placeholder copy) → **Confirm** as M-4.
- Codex M-6 (CTA inconsistency) → **Confirm** as M-1.
- Codex M-7 (legacy pages at root) → **Confirm** as M-3.
- Codex L-8 (duplicate h3) → **Reject** (see above).
- Codex L-9 (twitter SLA) → **Confirm** as L-1.

Additional items Codex missed:
- C-1 contact form has no submission backend.
- H-2 missing `<main>` on catalog and catalog-stone.
- M-5 `Products ▾` placeholder `href`.
- M-6 merchant placeholder links on contact page.
- M-7 `robots.txt` does not block legacy surface.
- L-2 missing canonical on two pages.
- L-3 supplier-brand-led titles on two product pages.
- L-4 two `<h1>`s shipped in A/B variant DOM.
- L-5 focus-visible gaps.
- L-6 class-naming inconsistency.

---

## Launch Verdict

**NO-GO** until the following blockers clear:
1. C-1: `contact.html` must submit to a real endpoint (Formspree/Basin/Netlify Forms/self-hosted). Minimum acceptable alternative: capture to a backend the team actually monitors, plus client-side success/failure state. `mailto:` handoff is not acceptable as the sole path.
2. H-1: remove the homepage A/B badge link to `ab-report.html`.
3. H-2: add `<main>` on `catalog.html` and `catalog-stone.html`.
4. H-3: wire the language buttons on `about.html` and `plye.html`, or hide the switcher on EN-only pages.
5. H-4: regenerate `sitemap.xml` to cover all production routes.

Once those clear, the Medium and Low items can batch into a second remediation pass without blocking launch.

---

## One-Pass Remediation Order (quick wins first)

Quick wins (under 30 min each, cumulative ~90 min):
1. Remove AB badge anchor from `index.html:1086`. Low risk.
2. Wire `onclick="setLang(...)"` on `about.html:348,350` and `plye.html:442,444`. Low risk.
3. Rename duplicate `id="residential"` on `applications.html:296,315` and update any anchor selectors. Low risk.
4. Remove or rewrite the internal placeholder paragraph at `catalog-stone.html:1235`. Low risk.
5. Replace `href="#"` on the three merchant anchors in `contact.html:763–765` with real URLs or hide the block. Low risk.
6. Soften the `twitter:description` SLA copy at `contact.html:29`. Low risk.

Medium (30–120 min each, cumulative 4–6 hours):
7. Stand up real form submission for `contact.html` (pick Formspree/Basin/Netlify Forms or custom endpoint), add success + error UI, keep mailto as a graceful fallback. **Blocker item — do first in this tier.**
8. Add `<main>` landmark to `catalog.html` and `catalog-stone.html`; verify `padding-top: 138px` rule still applies.
9. Normalize top-nav primary CTA across all 10 EN pages (pick sample-first with intent prefill); push Contact to secondary slot.
10. Regenerate `sitemap.xml` with all canonical routes; add `hreflang` alternates where EN/ZH both exist.
11. Add `<link rel="canonical">` to `catalog.html` and `applications.html`.
12. Point `Products ▾` trigger at a real route instead of `#`.

Structural / release hygiene:
13. Define a deploy allowlist that excludes `ab-report.html`, `plye-b.html`, `plye-c.html`, `stone-catalog.html`, and all `_*.html` files. If any must ship, apply `noindex` and drop `robots.txt` `Disallow:` entries.
14. Decide on supplier-brand-led `<title>` strings for `nalexible-stone.html` and `nalexible-fiberboard.html`.
15. Post-launch: normalize class naming, add a global `:focus-visible` rule, and replace the two-H1 A/B pattern with single-H1 + JS text swap.

---

## Final QA Gate (after the above)

- Desktop 1440: nav, hero CTAs, section flow, footer links.
- Tablet 1024 / 834: grid wrapping, sticky elements, CTA visibility.
- Mobile 430 / 390: menu overlay, card readability, no overlap.
- EN/ZH behavior: no dead toggles, language state consistent, `<html lang>` flips.
- CTA path QA: homepage → catalog → catalog-stone → contact prefill round-trip.
- Contact form QA: submit succeeds to backend; success state visible; failure state visible; server receives the payload.
- Console check: no JS errors on key pages (only known warn is `catalog-stone.html:1902` LumiSlate missing-asset warn).
- Legacy file surface: confirm production build does not publish `_*`, `ab-report.html`, `plye-b.html`, `plye-c.html`, `stone-catalog.html`.
